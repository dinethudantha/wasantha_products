<div class="top-bar">
    <div class="container">
        <div class="top-bar-content">
            <div class="business-hours">
                <i class="fas fa-clock"></i>
                <span>Mon-Sat: 09AM - 05PM</span>
            </div>
            <div class="social-links">
                <span>Follow Us:</span>
                <a href="https://www.facebook.com/wasanthaproducts?mibextid=wwXIfr&mibextid=wwXIfr" title="Facebook" target="_blanck"><i class="fab fa-facebook-f"></i></a>
                <a href="mailto:wasanthaproducts47@gmail.com" title="Email" target="_blanck"><i class="fas fa-envelope"></i></a>
                <a href="#" title="WhatsApp" target="_blanck"><i class="fab fa-whatsapp"></i></a>
            </div>
        </div>
    </div>
</div>